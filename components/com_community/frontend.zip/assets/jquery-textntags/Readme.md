jquery.textntags
=================

To get started -- checkout http://daniel-zahariev.github.com/jquery-textntags


*****

[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/daniel-zahariev/jquery-textntags/trend.png)](https://bitdeli.com/free "Bitdeli Badge")
